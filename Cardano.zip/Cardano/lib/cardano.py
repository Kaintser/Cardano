import cmath


class Cardano:  # тут находтся сам метод кордано и наоходятся корни в зависимости от параметра  Q(дельта)

    def Calculate(self, a, b, c, d):
        if b == 0 and c == 0 and d == 0:  # в случае если полином равен нулю
            print('неверные коэфиценты b,c,в')
            exit()
        elif a==0:
            print('неверные коэфиценты a')
            exit()

        p = (3 * a * c - b ** 2) / (3 * a ** 2)
        q = (2 * b ** 3 - 9 * a * b * c + 27 * a ** 2 * d) / (27 * a ** 3)
        Q = ((p / 3) ** 3 + (q / 2) ** 2)

        if Q - 0.000000001 < 0:  # 3 действительных корня

            if q == 0:  # находим фи
                F = cmath.pi / 2
            if q < 0:
                F = cmath.atan(-2 * cmath.sqrt(-Q) / q)
            if q > 0:
                F = cmath.atan(-2 * cmath.sqrt(-Q) / q) + cmath.pi

            X1 = 2 * (-p / 3) ** 0.5 * cmath.cos(F / 3) - b / (3 * a)
            X1 = round(X1.real, 15)
            X2 = 2 * (-p / 3) ** 0.5 * cmath.cos((F / 3) + 2 * cmath.pi / 3) - b / (3 * a)
            X2 = round(X2.real, 15)
            X3 = 2 * (-p / 3) ** 0.5 * cmath.cos((F / 3) + 4 * cmath.pi / 3) - b / (3 * a)
            X3 = round(X3.real, 15)
            return X1, X2, X3, Q

        elif Q == 0:  # 2 корня один из которых имеет кратность 2

            X1 = 2 * (-q / 2) ** (1 / 3) - b / (3 * a)
            X2 = (-q / 2) ** (-1 / 3) - b / (3 * a)
            X3 = (-q / 2) ** (-1 / 3) - b / (3 * a)

            return X1, X2, X3, Q
        elif Q > 0:

            print(p)
            print(q)
            print(Q)
            print('комплексноое число')

            exit()
