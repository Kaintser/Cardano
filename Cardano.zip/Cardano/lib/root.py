import random

class Root:

    def Create(self,min,max):
        x1 = random.uniform(min, max)
        x2 = random.uniform(min, max)
        x3 = random.uniform(min, max)

        return x1, x2, x3

    def Real(self, x1, x2, x3, X1, X2, X3, epsilon):  # для действительных
        while X1 > X2 or X2 > X3:
            if X1 > X2:
                sort = X2
                X2 = X1
                X1 = sort
            elif X2 > X3:
                sort = X3
                X3 = X2
                X2 = sort

        while x1 > x2 or x2 > x3:
            if x1 > x2:
                sort = x2
                x2 = x1
                x1 = sort
            elif x2 > x3:
                sort = x3
                x3 = x2
                x2 = sort

        if x1 >= X1:
            epsilon = epsilon + x1 - X1
        elif X1 > x1:
            epsilon = epsilon + X1 - x1

        if x2 >= X2:
            epsilon = epsilon + x2 - X2
        elif X2 > x2:
            epsilon = epsilon + X2 - x2

        if x3 >= X3:
            epsilon = epsilon + x3 - X3
        elif X3 >= x3:
            epsilon = epsilon + X3 - x3

        return  epsilon

    def Multiple(self, x1, x2, x3, X1, X2, X3, epsilon):  # для кратных
        while X1 > X2 or X2 > X3:
            if X1 > X2:
                sort = X2
                X2 = X1
                X1 = sort
            elif X2 > X3:
                sort = X3
                X3 = X2
                X2 = sort

        while x1 > x2 or x2 > x3:
            if x1 > x2:
                sort = x2
                x2 = x1
                x1 = sort
            elif x2 > x3:
                sort = x3
                x3 = x2
                x2 = sort

        if x1 >= X1:
            epsilon = epsilon + x1 - X1
        elif X1 > x1:
            epsilon = epsilon + X1 - x1

        if x2 >= X2:
            epsilon = epsilon + x2 - X2
        elif X2 > x2:
            epsilon = epsilon + X2 - x2

        if x3 >= X3:
            epsilon = epsilon + x3 - X3
        elif X3 >= x3:
            epsilon = epsilon + X3 - x3

        return  epsilon