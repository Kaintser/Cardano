from lib.cardano import Cardano
from lib.root import Root
from lib.polynomial import Polynomial

amount = int(input('Число тестов: '))
min = float(input('Минимальный предел x: '))
max = float(input('Максимальный предел x: '))

epsilon = 0  # переменная в которой будет содержаться среднее значение погрешности
infelicityCount = 0  # переменная в которую будет записываться сколько раз мы записывали в epsilon что бы найти
# среднее значение

for i in range(amount):
    x1, x2, x3 = Root().Create(min, max)

    a, b, c, d = Polynomial().Create(x1, x2, x3)

    X1, X2, X3, Q = Cardano().Calculate(a, b, c, d)

    if Q < 0 :

        epsilon = Root().Real(x1, x2, x3, X1, X2, X3, epsilon)

    elif Q == 0:

        epsilon = Root().Multiple(x1, x2, x3, X1, X2, X3, epsilon)



    if Q > 0 or Q == 0 or Q < 0:
        infelicityCount += 3

epsilon = epsilon / infelicityCount

f = open('MetodСardanoExit.txt', 'a', -1, 'utf-8')
f.write(str(epsilon))
f.close()
